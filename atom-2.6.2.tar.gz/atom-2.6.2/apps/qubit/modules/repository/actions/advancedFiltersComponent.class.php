<?php

/*
 * This file is part of the Access to Memory (AtoM) software.
 *
 * Access to Memory (AtoM) is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Access to Memory (AtoM) is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Access to Memory (AtoM).  If not, see <http://www.gnu.org/licenses/>.
 */

class RepositoryAdvancedFiltersComponent extends sfComponent
{
  public function execute($request)
  {
    // Store current params to add them as hidden inputs
    // in the form, to keep GET and POST params in sync
    $this->hiddenFields = array();
    foreach ($request->getGetParameters() as $key => $value)
    {
      // Keep control of what is added to avoid
      // Cross-Site Scripting vulnerability. Only allow:
      // - Aggregations
      // - Sort and view options
      // - subquery param
      // But ignore aggs already included in the form:
      // - thematicAreas, types and regions
      $allowed = array_merge(
        array_keys(RepositoryBrowseAction::$AGGS),
        array('view', 'sort', 'subquery')
      );
      $ignored = array('thematicAreas', 'types', 'regions');
      if (!in_array($key, $allowed) || in_array($key, $ignored))
      {
        continue;
      }

      $this->hiddenFields[$key] = $value;
    }
  }
}
